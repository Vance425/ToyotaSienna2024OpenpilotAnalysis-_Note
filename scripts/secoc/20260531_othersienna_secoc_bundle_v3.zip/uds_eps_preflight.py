#!/usr/bin/env python3
"""Read-only EPS UDS preflight for Sienna SecOC dump.

This sends only ReadDataByIdentifier(0xF181) probes to candidate EPS
addresses/buses and prints which one responds. It does not enter programming
session, request seed/key, upload payload, or dump memory.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


DEFAULT_OPENPILOT_DIR = os.environ.get("OPENPILOT_DIR", "/data/openpilot")


def parse_int(text: str) -> int:
  return int(str(text).strip(), 0)


def parse_list(values: list[str] | None, default: list[int]) -> list[int]:
  if not values:
    return default
  out = []
  for value in values:
    for part in value.split(","):
      part = part.strip()
      if part:
        out.append(parse_int(part))
  return sorted(set(out))


def import_stack():
  openpilot_dir = os.environ.get("OPENPILOT_DIR", DEFAULT_OPENPILOT_DIR)
  for path in (openpilot_dir, os.path.join(openpilot_dir, "panda", "python")):
    if path and path not in sys.path:
      sys.path.insert(0, path)
  try:
    from panda import Panda  # type: ignore
    try:
      from panda.python.uds import UdsClient, MessageTimeoutError  # type: ignore
    except Exception:
      from opendbc.car.uds import UdsClient, MessageTimeoutError  # type: ignore
  except Exception as exc:
    raise SystemExit(f"import_failed: {exc}")
  return Panda, UdsClient, MessageTimeoutError


def safety_elm327_value(Panda) -> int:
  return getattr(Panda, "SAFETY_ELM327", 3)


def main() -> int:
  parser = argparse.ArgumentParser(description="Read-only EPS UDS version preflight")
  parser.add_argument("--bus", action="append", help="bus list, repeatable/comma-separated; default 0,1,2")
  parser.add_argument("--tx-addr", action="append", help="tx addr list; default 0x7a1,0x7b0,0x700,0x750,0x7d2,0x780")
  parser.add_argument("--timeout", type=float, default=1.5)
  args = parser.parse_args()

  buses = parse_list(args.bus, [0, 1, 2])
  tx_addrs = parse_list(args.tx_addr, [0x7A1, 0x7B0, 0x700, 0x750, 0x7D2, 0x780])

  Panda, UdsClient, MessageTimeoutError = import_stack()
  panda = Panda()
  panda.set_safety_mode(safety_elm327_value(Panda))

  results = []
  for bus in buses:
    for tx in tx_addrs:
      rx = tx + 8
      item = {"bus": bus, "tx": f"0x{tx:x}", "rx": f"0x{rx:x}", "ok": False}
      try:
        client = UdsClient(panda, tx, rx, bus, timeout=args.timeout, debug=False)
        value = client.read_data_by_identifier(0xF181)
        item.update({"ok": True, "value_hex": value.hex(), "value_repr": repr(value)})
        print(f"[OK] bus={bus} tx=0x{tx:x} rx=0x{rx:x} f181={value.hex()} {value!r}")
      except MessageTimeoutError as exc:
        item["error"] = "timeout"
        print(f"[TIMEOUT] bus={bus} tx=0x{tx:x} rx=0x{rx:x}")
      except Exception as exc:
        item["error"] = type(exc).__name__
        item["detail"] = str(exc)
        print(f"[FAIL] bus={bus} tx=0x{tx:x} rx=0x{rx:x} {type(exc).__name__}: {exc}")
      results.append(item)

  hits = [item for item in results if item["ok"]]
  print("[SUMMARY] " + json.dumps({"hits": hits, "hit_count": len(hits)}, sort_keys=True))
  return 0 if hits else 1


if __name__ == "__main__":
  raise SystemExit(main())
