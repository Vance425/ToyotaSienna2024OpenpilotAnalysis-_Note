#!/usr/bin/env sh
set -eu

STAMP="$(date '+%Y%m%d_%H%M%S')"
echo "[INFO] stop_openpilot start ${STAMP}"

TMUX_BIN="${TMUX_BIN:-/usr/bin/tmux}"
COMMA_SESSION="${COMMA_SESSION:-comma}"
WAIT_SECONDS="${WAIT_SECONDS:-2}"
PATTERN='selfdrive\.manager\.manager|manager\.py|selfdrive\.boardd\.boardd|boardd'

if [ ! -x "${TMUX_BIN}" ]; then
  TMUX_BIN="$(command -v tmux || true)"
fi

if [ -n "${TMUX_BIN}" ] && "${TMUX_BIN}" has-session -t "${COMMA_SESSION}" 2>/dev/null; then
  echo "[INFO] killing tmux session: ${COMMA_SESSION}"
  "${TMUX_BIN}" kill-session -t "${COMMA_SESSION}" || true
else
  echo "[INFO] tmux session not running: ${COMMA_SESSION}"
fi

if pgrep -f "${PATTERN}" >/dev/null 2>&1; then
  echo "[INFO] sending TERM to openpilot manager/boardd processes"
  pkill -TERM -f "${PATTERN}" || true
else
  echo "[INFO] openpilot manager/boardd processes not found"
fi

sleep "${WAIT_SECONDS}"

if pgrep -f "${PATTERN}" >/dev/null 2>&1; then
  echo "[WARN] processes still running after TERM:"
  ps -eo pid,ppid,stat,cmd | grep -E "${PATTERN}" | grep -v grep | sed -n '1,80p'
  if [ "${MY_SIENNA_STOP_OPENPILOT_FORCE:-0}" = "1" ]; then
    echo "[WARN] force enabled; sending KILL"
    pkill -KILL -f "${PATTERN}" || true
    sleep 1
  fi
fi

if pgrep -f "${PATTERN}" >/dev/null 2>&1; then
  echo "[ERROR] openpilot still appears to be running"
  ps -eo pid,ppid,stat,cmd | grep -E "${PATTERN}" | grep -v grep | sed -n '1,80p'
  exit 2
fi

if [ -n "${TMUX_BIN}" ] && "${TMUX_BIN}" has-session -t "${COMMA_SESSION}" 2>/dev/null; then
  echo "[ERROR] tmux session still exists: ${COMMA_SESSION}"
  exit 2
fi

echo "[DONE] openpilot stopped"
