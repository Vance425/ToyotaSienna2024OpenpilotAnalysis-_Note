#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUTPUT_ROOT="${MY_SIENNA_SECOC_DUMP_ROOT:-/data/secoc_dumps}"
OUTPUT_DIR=""
SCRIPT_PATH="${MY_SIENNA_SECOC_DUMP_SCRIPT:-}"
OPENPILOT_DIR="${OPENPILOT_DIR:-/data/openpilot}"
PYTHON_BIN="${PYTHON_BIN:-}"

if [[ -z "$PYTHON_BIN" ]]; then
  for candidate in \
    "${OPENPILOT_DIR}/.venv/bin/python3" \
    "${OPENPILOT_DIR}/.venv/bin/python" \
    "/usr/local/venv/bin/python3" \
    "/usr/bin/python3" \
    "python3"; do
    if command -v "$candidate" >/dev/null 2>&1 || [[ -x "$candidate" ]]; then
      PYTHON_BIN="$candidate"
      break
    fi
  done
fi

if [[ -z "$PYTHON_BIN" ]]; then
  echo "[FAIL] python3 not found"
  exit 1
fi

if [[ -d "$OPENPILOT_DIR" ]]; then
  export PYTHONPATH="${OPENPILOT_DIR}:${OPENPILOT_DIR}/opendbc_repo${PYTHONPATH:+:$PYTHONPATH}"
fi

if [[ "${1:-}" == "--output-dir" ]]; then
  OUTPUT_DIR="$2"
  shift 2
fi

EXTRA_ARGS=("$@")
HAS_RUN_STAMP=0
HAS_DATED_FILES=0
HAS_DRY_RUN_PROFILE=0
HAS_DRY_RUN_IMPORTS=0
HAS_DEBUG=0
for arg in "${EXTRA_ARGS[@]}"; do
  if [[ "$arg" == "--run-stamp" ]]; then
    HAS_RUN_STAMP=1
  fi
  if [[ "$arg" == "--dated-files" ]]; then
    HAS_DATED_FILES=1
  fi
  if [[ "$arg" == "--dry-run-profile" ]]; then
    HAS_DRY_RUN_PROFILE=1
  fi
  if [[ "$arg" == "--dry-run-imports" ]]; then
    HAS_DRY_RUN_IMPORTS=1
  fi
  if [[ "$arg" == "--debug" ]]; then
    HAS_DEBUG=1
  fi
done
if [[ "$HAS_RUN_STAMP" -eq 0 ]]; then
  EXTRA_ARGS=("--run-stamp" "$STAMP" "${EXTRA_ARGS[@]}")
fi
if [[ "$HAS_DATED_FILES" -eq 0 ]]; then
  EXTRA_ARGS=("--dated-files" "${EXTRA_ARGS[@]}")
fi
if [[ "$HAS_DRY_RUN_PROFILE" -eq 1 && "$HAS_DRY_RUN_IMPORTS" -eq 0 ]]; then
  EXTRA_ARGS=("--dry-run-imports" "${EXTRA_ARGS[@]}")
fi
if [[ "$HAS_DRY_RUN_PROFILE" -eq 0 && "$HAS_DEBUG" -eq 0 ]]; then
  EXTRA_ARGS=("--debug" "${EXTRA_ARGS[@]}")
fi

if [[ -z "$OUTPUT_DIR" ]]; then
  OUTPUT_DIR="${OUTPUT_ROOT}/sienna2024_secoc_dump_${STAMP}"
fi

if [[ -e "$OUTPUT_DIR" ]]; then
  OUTPUT_DIR="${OUTPUT_DIR}_$$"
fi

if [[ -z "$SCRIPT_PATH" ]]; then
  for candidate in \
    "${SCRIPT_DIR}/extract_keys_sienna2024_dump_only.py" \
    "${SCRIPT_DIR}/secoc/extract_keys_sienna2024_dump_only.py" \
    "/data/tools/mySienna_api/extract_keys_sienna2024_dump_only.py" \
    "/data/tools/mySienna_api/secoc/extract_keys_sienna2024_dump_only.py" \
    "/data/tools/secoc/extract_keys_sienna2024_dump_only.py"; do
    if [[ -f "$candidate" ]]; then
      SCRIPT_PATH="$candidate"
      break
    fi
  done
fi

if [[ -z "$SCRIPT_PATH" || ! -f "$SCRIPT_PATH" ]]; then
  echo "[FAIL] extract_keys_sienna2024_dump_only.py not found"
  echo "[HINT] Put extract_keys_sienna2024_dump_only.py in the same directory as this runner:"
  echo "[HINT] ${SCRIPT_DIR}/extract_keys_sienna2024_dump_only.py"
  echo "[HINT] Or set MY_SIENNA_SECOC_DUMP_SCRIPT=/path/to/extract_keys_sienna2024_dump_only.py"
  exit 1
fi

mkdir -p "$OUTPUT_DIR"

echo "[INFO] Sienna 2024 SecOC dump start: ${STAMP}"
echo "[INFO] script: ${SCRIPT_PATH}"
echo "[INFO] output_dir: ${OUTPUT_DIR}"
echo "[INFO] openpilot_dir: ${OPENPILOT_DIR}"
echo "[INFO] python: ${PYTHON_BIN}"
echo "[INFO] pythonpath: ${PYTHONPATH:-}"
echo "[INFO] command: ${PYTHON_BIN} ${SCRIPT_PATH} --output-dir ${OUTPUT_DIR} ${EXTRA_ARGS[*]}"

"$PYTHON_BIN" "$SCRIPT_PATH" --output-dir "$OUTPUT_DIR" "${EXTRA_ARGS[@]}"

echo "[DONE] Sienna 2024 SecOC dump finished"
echo "[DONE] output_dir: ${OUTPUT_DIR}"
