#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPENPILOT_DIR="${OPENPILOT_DIR:-/data/openpilot}"
PYTHON_BIN="${PYTHON_BIN:-/usr/local/venv/bin/python3}"
STOP_OPENPILOT_SCRIPT="${STOP_OPENPILOT_SCRIPT:-${SCRIPT_DIR}/stop_openpilot.sh}"
DUMP_RUNNER="${DUMP_RUNNER:-${SCRIPT_DIR}/run_sienna2024_secoc_dump.sh}"
OUTPUT_ROOT="${OUTPUT_ROOT:-/data/secoc_dumps}"

PROFILE="sienna_2024_eps_dataflash"
ACK_PARKED=0
DRY_RUN=0
STOP_OPENPILOT=1
FORCE_STOP_OPENPILOT=0
EXTRA_ARGS=()

usage() {
  cat <<'EOF'
Usage:
  sh run_other_sienna_dataflash_dump.sh --ack-parked [options]

Safe dry-run:
  sh run_other_sienna_dataflash_dump.sh --dry-run

Options:
  --ack-parked              Required for real dump. Confirms vehicle is parked, not driving.
  --dry-run                 Check profile/payload/imports only; does not open Panda or touch ECU.
  --profile NAME            Default: sienna_2024_eps_dataflash.
  --output-root DIR         Default: /data/secoc_dumps.
  --no-stop-openpilot       Do not stop openpilot first. Not recommended.
  --force-stop-openpilot    Force kill openpilot if normal stop fails.
  --                        Pass remaining args to extract_keys_sienna2024_dump_only.py.

Common profiles:
  sienna_2024_eps_dataflash       dumps 0xff200000:0xff208000
  sienna_2024_eps_dataflash_b     dumps 0xff208000:0xff210000
  sienna_2024_eps_dataflash_prev  dumps 0xff1f8000:0xff200000

Important:
  This EPS UDS/dataflash dump can affect power steering assist. Run only while parked.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --ack-parked)
      ACK_PARKED=1
      shift
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    --profile)
      PROFILE="$2"
      shift 2
      ;;
    --output-root)
      OUTPUT_ROOT="$2"
      shift 2
      ;;
    --no-stop-openpilot)
      STOP_OPENPILOT=0
      shift
      ;;
    --force-stop-openpilot)
      STOP_OPENPILOT=1
      FORCE_STOP_OPENPILOT=1
      shift
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    --)
      shift
      EXTRA_ARGS+=("$@")
      break
      ;;
    *)
      EXTRA_ARGS+=("$1")
      shift
      ;;
  esac
done

if [[ "${DRY_RUN}" != "1" && "${ACK_PARKED}" != "1" ]]; then
  echo "[ERROR] Real dump requires --ack-parked." >&2
  echo "[HINT] For a safe check only, run: sh run_other_sienna_dataflash_dump.sh --dry-run" >&2
  exit 2
fi

if [[ ! -x "${DUMP_RUNNER}" ]]; then
  echo "[ERROR] dump runner not executable: ${DUMP_RUNNER}" >&2
  exit 2
fi

if [[ "${DRY_RUN}" != "1" && "${STOP_OPENPILOT}" = "1" ]]; then
  if [[ ! -x "${STOP_OPENPILOT_SCRIPT}" ]]; then
    echo "[ERROR] stop_openpilot script not executable: ${STOP_OPENPILOT_SCRIPT}" >&2
    exit 2
  fi
  echo "[INFO] stopping openpilot before DATAFLASH dump"
  if [[ "${FORCE_STOP_OPENPILOT}" = "1" ]]; then
    MY_SIENNA_STOP_OPENPILOT_FORCE=1 "${STOP_OPENPILOT_SCRIPT}"
  else
    "${STOP_OPENPILOT_SCRIPT}"
  fi
fi

STAMP="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="${OUTPUT_ROOT}/other_sienna_${PROFILE}_${STAMP}"

COMMON_ARGS=(
  "--output-dir" "${OUT_DIR}"
  "--profile" "${PROFILE}"
)

if [[ "${DRY_RUN}" = "1" ]]; then
  echo "[INFO] dry-run only; Panda/ECU will not be opened"
  COMMON_ARGS+=("--dry-run-profile")
else
  COMMON_ARGS+=("--unsafe-ack-parked")
fi

echo "[INFO] profile: ${PROFILE}"
echo "[INFO] output: ${OUT_DIR}"
echo "[INFO] runner: ${DUMP_RUNNER}"

exec "${DUMP_RUNNER}" "${COMMON_ARGS[@]}" "${EXTRA_ARGS[@]}"
