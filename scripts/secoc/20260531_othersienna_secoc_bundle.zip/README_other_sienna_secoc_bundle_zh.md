# 2024 Sienna SecOC Capture/Dump Bundle

這包是給另一台 2024 Toyota Sienna 在 C3X 上使用的工具包。

## 內容

- `capture_secoc_frames.py`
  - 只收 CAN frames，不送 UDS、不送控制訊息。
- `run_capture_secoc_frames.sh`
  - 建議用這支收 SecOC frames。
  - 可用 `--stop-openpilot` 先停 openpilot。
- `run_other_sienna_dataflash_dump.sh`
  - 建議用這支做 EPS DATAFLASH dump。
  - 實際 dump 必須加 `--ack-parked`。
- `run_sienna2024_secoc_dump.sh`
  - DATAFLASH dump runner。
- `extract_keys_sienna2024_dump_only.py`
  - EPS dump 主程式，只 dump，不寫 SecOCKey。
- `stop_openpilot.sh`
  - 停 openpilot/manager/boardd，避免 Panda 被占用。
- `payload_dataflash_ff200000_ff208000.bin`
  - 預設 DATAFLASH dump payload。
- `payload_candidate_f05_dataflash_ff200000_ff208000.bin`
  - 保留候選 payload，預設不使用。

## 安裝

把整包解到 C3X：

```bash
mkdir -p /data/tools/mySienna_api
cd /data/tools/mySienna_api
unzip /path/to/other_sienna_secoc_bundle.zip
chmod 755 *.sh *.py
```

## 先做安全 dry-run

這個不會開 Panda、不會碰 ECU：

```bash
cd /data/tools/mySienna_api
sh run_other_sienna_dataflash_dump.sh --dry-run
```

看到 `payload_resolved`、`dry_run_runtime_imports`、`dry_run_profile_done` 才算 OK。

## 收 SecOC frames

車子 READY，建議先開始 capture，10-20 秒後開 ACC，維持到結束。

```bash
cd /data/tools/mySienna_api
sh run_capture_secoc_frames.sh \
  --stop-openpilot \
  --duration 120 \
  --target-addr 0x2e4 \
  --sync-addr 0x0f \
  --output-dir /data/secoc_frame_capture
```

結束會顯示：

```text
[DONE] capture finished
[DONE] output=/data/secoc_frame_capture/secoc_frames_YYYYMMDD_HHMMSS
[DONE] sync=... protected=... total=...
```

要帶回來的資料夾：

```text
/data/secoc_frame_capture/secoc_frames_YYYYMMDD_HHMMSS
```

## 做 DATAFLASH dump

重要：車子必須停好、P 檔、不要行駛。這是 EPS UDS/DATAFLASH dump，執行途中可能影響方向盤輔助。

```bash
cd /data/tools/mySienna_api
sh run_other_sienna_dataflash_dump.sh --ack-parked
```

預設輸出：

```text
/data/secoc_dumps/other_sienna_sienna_2024_eps_dataflash_YYYYMMDD_HHMMSS
```

如果正常 TERM 停不掉 openpilot，可改用：

```bash
sh run_other_sienna_dataflash_dump.sh --force-stop-openpilot --ack-parked
```

## 帶回資料

請把這兩類資料夾打包帶回：

```text
/data/secoc_frame_capture/secoc_frames_YYYYMMDD_HHMMSS
/data/secoc_dumps/other_sienna_sienna_2024_eps_dataflash_YYYYMMDD_HHMMSS
```

如果 dump timeout，也請帶回整個輸出資料夾；裡面可能會有 `.partial.bin` 和 metadata，可判斷抓到多少 bytes/frames。
