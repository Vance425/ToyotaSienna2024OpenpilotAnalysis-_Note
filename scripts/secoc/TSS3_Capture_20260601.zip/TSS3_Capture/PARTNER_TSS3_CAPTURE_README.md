# Partner TSS3.0 Read-Only Capture

This workflow is for the partner 2024 Sienna TSS3.0 vehicle. Keep these captures separate from the user's TSS2.5 data.

## Goal
- Collect qlog-like CAN timing data when comma connect is unavailable.
- Focus on TSS3.0 read-only evidence around `0x2e4`, `0x131`, `0x2e5`, and `0x0f`.
- Do not send CAN, ISO-TP, UDS, seed/key, routine-control, or programming-session traffic.

## Files
- `tools/partner_tss3_readonly_capture.py`: run this on the comma/openpilot device.
- Output is written under `/data/partner_tss3_captures/`.
- Each run creates a folder and a matching `.zip` bundle.

## Install/Copy
Copy the script to the device, for example:

```sh
mkdir -p /data/openpilot/scripts/partner_tss3
cp partner_tss3_readonly_capture.py /data/openpilot/scripts/partner_tss3/
chmod +x /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py
```

If running from outside `/data/openpilot`, make sure Python can import openpilot/cereal:

```sh
export PYTHONPATH=/data/openpilot:/data/openpilot/opendbc_repo:/data/pythonpath
```

## Basic Run
Run parked/offroad or with openpilot stopped if you only need raw bus behavior:

```sh
cd /data/openpilot
/usr/local/pyenv/shims/python /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py \
  --duration 120 \
  --owner partner \
  --vehicle-tag partner_tss3 \
  --label ignition_on_stationary
```

If that Python path does not exist, try:

```sh
cd /data/openpilot
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py \
  --duration 120 \
  --owner partner \
  --vehicle-tag partner_tss3 \
  --label ignition_on_stationary
```

## Recommended Capture Set
Capture multiple short, clearly labeled states:

```sh
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py --duration 120 --owner partner --vehicle-tag partner_tss3 --label ignition_on_stationary
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py --duration 120 --owner partner --vehicle-tag partner_tss3 --label acc_standby
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py --duration 180 --owner partner --vehicle-tag partner_tss3 --label acc_active
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py --duration 180 --owner partner --vehicle-tag partner_tss3 --label lta_steering_active
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py --duration 120 --owner partner --vehicle-tag partner_tss3 --label acc_cancel_or_disengage
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py --duration 120 --owner partner --vehicle-tag partner_tss3 --label after_power_cycle
```

For each run, write down:
- Vehicle state: parked, driving, ACC standby, ACC active, LTA active, disengage, power cycle.
- Whether openpilot was running, stopped, or disengaged.
- Approximate time and route context.
- Any steering wheel buttons or state changes during the capture.

## Output Bundle
Each run contains:
- `metadata.json`: capture label, params, process state, target IDs.
- `summary.json`: top CAN IDs, frame counts, target/sync counts.
- `frames.csv`: all captured CAN frames.
- `frames.jsonl`: all captured CAN frames as JSONL.
- `protected_frames.jsonl`: filtered target IDs, default `0x2e4`, `0x131`, `0x2e5`.
- `sync_frames.jsonl`: filtered sync IDs, default `0x0f`.

Send back the `.zip` files from `/data/partner_tss3_captures/`.

## Local Trial on the User's Vehicle
The same read-only tool can be run on the user's own vehicle first to validate the workflow before asking the partner to run it.

Keep the output labels explicit, for example:

```sh
python3 /data/openpilot/scripts/partner_tss3/partner_tss3_readonly_capture.py \
  --duration 120 \
  --owner user \
  --vehicle-tag user_tss25 \
  --label user_tss25_ignition_on_stationary
```

After copying the zip back to this workspace, run:

```powershell
& 'C:\Users\vance\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' `
  'tools\analyze_readonly_capture.py' `
  'PATH_TO_CAPTURE_ZIP_OR_FOLDER' `
  --output 'user_tss25_capture_analysis.json'
```

The analyzer reports:
- cadence by CAN ID;
- fixed byte positions;
- rolling/freshness-like byte candidates;
- high-entropy auth/tag-like byte positions;
- timing relation between target frames and sync frames.

Use the user's TSS2.5 result as a workflow validation baseline only. Do not merge user TSS2.5 data with partner TSS3.0 data.

## Vehicle Identification
The capture script writes `vehicle_identity` into `metadata.json` and prefixes the output folder/zip with owner and vehicle tag.

Use explicit tags whenever possible:

```sh
--owner user --vehicle-tag user_tss25
--owner partner --vehicle-tag partner_tss3
```

If explicit tags are omitted, the script tries to decode `CarParams` and classify from `carName` / `carFingerprint`. If it cannot classify confidently, it marks the capture as `unknown_unknown_vehicle_...`.

## Notes
- This tool is intentionally read-only.
- It is meant to replace the useful qlog/connect evidence path, not the UDS/dataflash path.
- The current TSS3.0 candidates are `0x2e4`, `0x131`, and sync candidate `0x0f`.
