#!/usr/bin/env python3
"""
Analyze read-only CAN capture bundles produced by partner_tss3_readonly_capture.py.

The analysis is structural only: cadence, fixed bytes, rolling-byte candidates,
high-entropy byte positions, and sync timing. It does not try to recover keys.
"""

import argparse
import csv
import json
import math
import statistics
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from tempfile import TemporaryDirectory


DEFAULT_ADDRS = ["0x2e4", "0x131", "0x2e5", "0x00f", "0xf"]


def norm_addr(text):
  return f"0x{int(str(text), 0):x}"


def entropy(values):
  if not values:
    return 0.0
  counts = Counter(values)
  total = len(values)
  return -sum((count / total) * math.log2(count / total) for count in counts.values())


def open_capture(path):
  path = Path(path)
  if path.is_dir():
    return path, None
  if path.suffix.lower() != ".zip":
    raise SystemExit(f"Unsupported input: {path}")
  tmp = TemporaryDirectory()
  with zipfile.ZipFile(path) as zf:
    zf.extractall(tmp.name)
  roots = [p for p in Path(tmp.name).iterdir() if p.is_dir()]
  if len(roots) == 1:
    return roots[0], tmp
  return Path(tmp.name), tmp


def read_rows(capture_dir, addrs=None):
  frames = capture_dir / "frames.csv"
  if not frames.exists():
    raise SystemExit(f"Missing frames.csv under {capture_dir}")
  wanted = {norm_addr(x) for x in addrs} if addrs else None
  rows = []
  with frames.open(newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
      addr = norm_addr(row["addr_hex"])
      if wanted is not None and addr not in wanted:
        continue
      data = row["data"].lower()
      rows.append({
        "seq": int(row["seq"]),
        "ts": float(row["ts_mono"]),
        "bus": int(row["bus"]),
        "addr": addr,
        "dlc": int(row["dlc"]),
        "data": data,
        "bytes": [int(data[i:i + 2], 16) for i in range(0, len(data), 2)],
      })
  return rows


def dedupe_rows(rows):
  out = []
  last = None
  for row in rows:
    sig = (row["ts"], row["addr"], row["data"])
    if sig == last:
      continue
    out.append(row)
    last = sig
  return out


def addr_report(rows):
  by_addr = defaultdict(list)
  for row in rows:
    by_addr[row["addr"]].append(row)

  reports = {}
  for addr, addr_rows in sorted(by_addr.items(), key=lambda item: int(item[0], 0)):
    compact = dedupe_rows(addr_rows)
    gaps = [
      compact[i]["ts"] - compact[i - 1]["ts"]
      for i in range(1, len(compact))
      if compact[i]["ts"] != compact[i - 1]["ts"]
    ]
    max_dlc = max((row["dlc"] for row in compact), default=0)
    byte_reports = []
    for idx in range(max_dlc):
      vals = [row["bytes"][idx] for row in compact if len(row["bytes"]) > idx]
      uniq = len(set(vals))
      fixed = uniq == 1
      transition_vals = []
      last = None
      for value in vals:
        if value != last:
          transition_vals.append(value)
          last = value
      diffs = [
        (transition_vals[i] - transition_vals[i - 1]) % 256
        for i in range(1, len(transition_vals))
      ]
      diff_top = Counter(diffs).most_common(6)
      byte_reports.append({
        "index": idx,
        "unique": uniq,
        "fixed": fixed,
        "fixed_hex": f"0x{vals[0]:02x}" if vals else None,
        "entropy_bits": round(entropy(vals), 3),
        "top_values": [[f"0x{k:02x}", v] for k, v in Counter(vals).most_common(6)],
        "transition_diffs": [[f"0x{k:02x}", v] for k, v in diff_top],
      })

    rolling_candidates = [
      b for b in byte_reports
      if 8 <= b["unique"] <= 128 and b["entropy_bits"] >= 2.0
    ]
    high_entropy_candidates = [
      b for b in byte_reports
      if b["unique"] >= 128 and b["entropy_bits"] >= 6.0
    ]

    reports[addr] = {
      "count": len(addr_rows),
      "deduped_count": len(compact),
      "unique_payloads": len({row["data"] for row in compact}),
      "dlc_counts": dict(Counter(row["dlc"] for row in compact)),
      "gap_ms": {
        "median": round(statistics.median(gaps) * 1000, 3) if gaps else None,
        "min": round(min(gaps) * 1000, 3) if gaps else None,
        "max": round(max(gaps) * 1000, 3) if gaps else None,
      },
      "first_payloads": [row["data"] for row in compact[:12]],
      "byte_reports": byte_reports,
      "rolling_candidates": [b["index"] for b in rolling_candidates],
      "high_entropy_candidates": [b["index"] for b in high_entropy_candidates],
    }
  return reports


def sync_report(rows, target_addr, sync_addr):
  targets = [row for row in rows if row["addr"] == norm_addr(target_addr)]
  syncs = [row for row in rows if row["addr"] == norm_addr(sync_addr)]
  if not targets or not syncs:
    return None
  syncs = sorted(syncs, key=lambda row: row["ts"])
  targets = sorted(targets, key=lambda row: row["ts"])
  idx = 0
  deltas = []
  for target in targets:
    while idx + 1 < len(syncs) and syncs[idx + 1]["ts"] <= target["ts"]:
      idx += 1
    if syncs[idx]["ts"] <= target["ts"]:
      deltas.append(target["ts"] - syncs[idx]["ts"])
  if not deltas:
    return None
  buckets = Counter(round(delta * 1000, 1) for delta in deltas)
  return {
    "target": norm_addr(target_addr),
    "sync": norm_addr(sync_addr),
    "pairs": len(deltas),
    "delta_ms": {
      "median": round(statistics.median(deltas) * 1000, 3),
      "min": round(min(deltas) * 1000, 3),
      "max": round(max(deltas) * 1000, 3),
    },
    "top_delta_buckets_ms": buckets.most_common(12),
  }


def summarize(args):
  capture_dir, tmp = open_capture(args.input)
  try:
    rows = read_rows(capture_dir, args.addrs)
    reports = addr_report(rows)
    syncs = []
    for target in args.target:
      for sync in args.sync:
        item = sync_report(rows, target, sync)
        if item:
          syncs.append(item)
    result = {
      "input": str(args.input),
      "capture_dir": str(capture_dir),
      "addr_reports": reports,
      "sync_reports": syncs,
    }
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.output:
      Path(args.output).write_text(text + "\n", encoding="utf-8")
  finally:
    if tmp is not None:
      tmp.cleanup()


def main():
  parser = argparse.ArgumentParser(description="Analyze read-only CAN capture output.")
  parser.add_argument("input", help="Capture directory or zip.")
  parser.add_argument("--addrs", nargs="*", default=DEFAULT_ADDRS, help="CAN IDs to analyze.")
  parser.add_argument("--target", nargs="*", default=["0x2e4", "0x131"], help="Target IDs for sync correlation.")
  parser.add_argument("--sync", nargs="*", default=["0xf"], help="Sync IDs for timing correlation.")
  parser.add_argument("--output", help="Optional JSON output path.")
  args = parser.parse_args()
  summarize(args)


if __name__ == "__main__":
  main()
