#!/usr/bin/env python3
"""
Read-only CAN capture helper for the partner 2024 Sienna TSS3.0 dataset.

This script subscribes to openpilot's cereal `can` stream and writes a small
qlog-like bundle that can be copied back for offline analysis. It does not send
CAN, ISO-TP, or UDS traffic.
"""

import argparse
import csv
import base64
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_TARGET_ADDRS = [0x2E4, 0x131, 0x2E5]
DEFAULT_SYNC_ADDRS = [0x00F]


def parse_addr_list(text):
  out = []
  if not text:
    return out
  for part in text.split(","):
    part = part.strip()
    if not part:
      continue
    out.append(int(part, 0))
  return out


def addr_hex(addr):
  return f"0x{addr:x}"


def now_stamp():
  return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def slug(text, fallback="capture"):
  text = safe_text(text).strip().lower()
  text = re.sub(r"[^a-z0-9_.-]+", "_", text)
  text = text.strip("._-")
  return text or fallback


def safe_text(value):
  if value is None:
    return ""
  if isinstance(value, bytes):
    return value.decode("utf-8", "replace")
  return str(value)


def decode_car_params(raw_text):
  if not raw_text:
    return {}
  result = {
    "raw_len": len(raw_text),
  }
  raw = raw_text.encode("latin1", "ignore")
  try:
    import cereal.car
    cp = cereal.car.CarParams.from_bytes(raw)
    result.update({
      "source": "capnp",
      "carName": safe_text(cp.carName),
      "carFingerprint": safe_text(cp.carFingerprint),
      "carVin": safe_text(cp.carVin),
      "openpilotLongitudinalControl": bool(cp.openpilotLongitudinalControl),
      "pcmCruise": bool(cp.pcmCruise),
      "flags": int(cp.flags),
      "safetyConfigs": [
        {
          "safetyModel": safe_text(item.safetyModel),
          "safetyParam": int(item.safetyParam),
        }
        for item in cp.safetyConfigs
      ],
    })
    return result
  except Exception as exc:
    result["capnp_error"] = safe_text(exc)
  try:
    decoded = base64.b64decode(raw_text, validate=True)
    import cereal.car
    cp = cereal.car.CarParams.from_bytes(decoded)
    result.update({
      "source": "base64_capnp",
      "carName": safe_text(cp.carName),
      "carFingerprint": safe_text(cp.carFingerprint),
      "carVin": safe_text(cp.carVin),
      "openpilotLongitudinalControl": bool(cp.openpilotLongitudinalControl),
      "pcmCruise": bool(cp.pcmCruise),
      "flags": int(cp.flags),
      "safetyConfigs": [
        {
          "safetyModel": safe_text(item.safetyModel),
          "safetyParam": int(item.safetyParam),
        }
        for item in cp.safetyConfigs
      ],
    })
    return result
  except Exception as exc:
    result["base64_capnp_error"] = safe_text(exc)
  return result


def classify_vehicle(car_params, args):
  fingerprint = safe_text(car_params.get("carFingerprint", ""))
  car_name = safe_text(car_params.get("carName", ""))
  text = f"{car_name} {fingerprint}".upper()
  if args.owner:
    owner = args.owner
  elif "TSS25" in text or "TSS2_5" in text or "TSS2.5" in text or "PLUS" in text:
    owner = "user"
  elif "TSS3" in text or "2024" in text:
    owner = "partner"
  else:
    owner = "unknown"

  if args.vehicle_tag:
    vehicle_tag = args.vehicle_tag
  elif owner == "user":
    vehicle_tag = "user_tss25"
  elif owner == "partner":
    vehicle_tag = "partner_tss3"
  else:
    vehicle_tag = "unknown_vehicle"

  return {
    "owner": owner,
    "vehicle_tag": vehicle_tag,
    "carName": car_name,
    "carFingerprint": fingerprint,
    "classification_rule": "explicit args > CarParams fingerprint/name heuristic > unknown",
  }


def read_param(name):
  paths = [
    Path("/data/params/d") / name,
    Path("/cache/params") / name,
  ]
  for path in paths:
    try:
      if path.exists():
        data = path.read_bytes()
        return data.decode("utf-8", "replace").strip()
    except Exception as exc:
      return f"<read_error:{exc}>"
  return None


def run_cmd(cmd, timeout=3):
  try:
    return subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=timeout).decode("utf-8", "replace").strip()
  except Exception as exc:
    return f"<cmd_error:{exc}>"


def collect_metadata(args, run_dir):
  param_names = [
    "CarParams",
    "DongleId",
    "Version",
    "GitCommit",
    "GitBranch",
    "GitRemote",
    "ControlsReady",
    "Passive",
    "DisableUpdates",
    "LastManagerExitReason",
  ]
  params = {name: read_param(name) for name in param_names}
  car_params_decoded = decode_car_params(params.get("CarParams"))
  vehicle_identity = classify_vehicle(car_params_decoded, args)
  metadata = {
    "tool": "partner_tss3_readonly_capture.py",
    "safety_note": "read-only capture; this script does not call can_send/isotp_send/UDS",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "label": args.label,
    "owner_arg": args.owner,
    "vehicle_tag_arg": args.vehicle_tag,
    "vehicle_identity": vehicle_identity,
    "duration_sec": args.duration,
    "buses": args.buses,
    "target_addrs": [addr_hex(x) for x in args.target_addrs],
    "sync_addrs": [addr_hex(x) for x in args.sync_addrs],
    "output_dir": str(run_dir),
    "python": sys.version,
    "platform": platform.platform(),
    "hostname": platform.node(),
    "cwd": os.getcwd(),
    "openpilot_processes": run_cmd(["sh", "-lc", "pgrep -af 'manager.py|controlsd|boardd|pandad|selfdrive.ui.ui' || true"]),
    "params": params,
    "car_params_decoded": car_params_decoded,
  }
  return metadata


def import_messaging():
  try:
    from cereal import messaging
    return messaging
  except Exception as exc:
    raise SystemExit(
      "Unable to import cereal.messaging. Run this on the comma/openpilot device "
      "with PYTHONPATH including /data/openpilot. Original error: %s" % exc
    )


def can_to_rows(msg, seq_base):
  rows = []
  mono_ns = int(getattr(msg, "logMonoTime", 0) or 0)
  mono_sec = mono_ns / 1e9 if mono_ns else time.monotonic()
  wall = time.time()
  can_list = getattr(msg, "can", [])
  seq = seq_base
  for can in can_list:
    seq += 1
    data = bytes(can.dat).hex()
    addr = int(can.address)
    bus = int(can.src)
    rows.append({
      "seq": seq,
      "ts_mono": mono_sec,
      "ts_wall": wall,
      "bus": bus,
      "addr": addr,
      "addr_hex": addr_hex(addr),
      "dlc": len(bytes(can.dat)),
      "data": data,
    })
  return seq, rows


def write_jsonl_line(handle, obj):
  handle.write(json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n")


def capture(args):
  messaging = import_messaging()

  stamp = now_stamp()
  pre_metadata_dir = Path(args.output_dir).expanduser()
  pre_metadata_dir.mkdir(parents=True, exist_ok=True)
  temp_run_dir = pre_metadata_dir / f"readonly_capture_pending_{stamp}"
  temp_run_dir.mkdir(parents=True, exist_ok=False)
  metadata = collect_metadata(args, temp_run_dir)
  identity = metadata["vehicle_identity"]
  prefix = f"{slug(identity.get('owner'), 'unknown')}_{slug(identity.get('vehicle_tag'), 'vehicle')}_{slug(args.label, 'capture')}_{stamp}"
  run_dir = pre_metadata_dir / prefix
  temp_run_dir.rename(run_dir)
  metadata["output_dir"] = str(run_dir)
  metadata["run_name"] = prefix
  (run_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")

  target_set = set(args.target_addrs)
  sync_set = set(args.sync_addrs)
  bus_filter = None if args.buses == "all" else {int(x.strip(), 0) for x in args.buses.split(",") if x.strip()}

  counts_by_bus = Counter()
  counts_by_addr = Counter()
  unique_by_addr = defaultdict(set)
  protected_count = 0
  sync_count = 0
  seq = 0
  can_recv_errors = 0
  start = time.monotonic()
  end = start + args.duration

  sock = messaging.sub_sock("can")

  with (run_dir / "frames.csv").open("w", newline="") as csv_f, \
       (run_dir / "frames.jsonl").open("w") as all_f, \
       (run_dir / "protected_frames.jsonl").open("w") as protected_f, \
       (run_dir / "sync_frames.jsonl").open("w") as sync_f:
    writer = csv.DictWriter(csv_f, fieldnames=["seq", "ts_mono", "ts_wall", "bus", "addr_hex", "addr", "dlc", "data"])
    writer.writeheader()

    while time.monotonic() < end:
      try:
        msgs = messaging.drain_sock(sock, wait_for_one=True)
      except Exception:
        can_recv_errors += 1
        time.sleep(0.01)
        continue

      for msg in msgs:
        seq, rows = can_to_rows(msg, seq)
        for row in rows:
          if bus_filter is not None and row["bus"] not in bus_filter:
            continue
          writer.writerow(row)
          write_jsonl_line(all_f, row)
          counts_by_bus[str(row["bus"])] += 1
          counts_by_addr[row["addr_hex"]] += 1
          if len(unique_by_addr[row["addr_hex"]]) < args.unique_cap:
            unique_by_addr[row["addr_hex"]].add(row["data"])
          if row["addr"] in target_set:
            protected_count += 1
            write_jsonl_line(protected_f, row)
          if row["addr"] in sync_set:
            sync_count += 1
            write_jsonl_line(sync_f, row)

  elapsed = time.monotonic() - start
  summary = {
    "ok": True,
    "started_utc": metadata["created_utc"],
    "finished_utc": datetime.now(timezone.utc).isoformat(),
    "elapsed_sec": round(elapsed, 3),
    "total_frames": sum(counts_by_bus.values()),
    "can_recv_errors": can_recv_errors,
    "counts_by_bus": dict(counts_by_bus),
    "protected_frame_count": protected_count,
    "sync_frame_count": sync_count,
    "target_addrs": [addr_hex(x) for x in args.target_addrs],
    "sync_addrs": [addr_hex(x) for x in args.sync_addrs],
    "top_addrs": counts_by_addr.most_common(args.top_n),
    "unique_data_count_by_top_addr": {
      addr: len(unique_by_addr[addr])
      for addr, _ in counts_by_addr.most_common(args.top_n)
    },
    "files": {
      "metadata": str(run_dir / "metadata.json"),
      "summary": str(run_dir / "summary.json"),
      "all_csv": str(run_dir / "frames.csv"),
      "all_jsonl": str(run_dir / "frames.jsonl"),
      "protected_jsonl": str(run_dir / "protected_frames.jsonl"),
      "sync_jsonl": str(run_dir / "sync_frames.jsonl"),
    },
  }
  (run_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

  archive_base = str(run_dir)
  archive_path = shutil.make_archive(archive_base, "zip", root_dir=str(run_dir.parent), base_dir=run_dir.name)
  print(json.dumps({"ok": True, "run_dir": str(run_dir), "zip": archive_path, "summary": summary}, indent=2, sort_keys=True))


def main():
  parser = argparse.ArgumentParser(description="Read-only partner TSS3.0 CAN/qlog substitute capture.")
  parser.add_argument("--duration", type=float, default=120.0, help="Capture duration in seconds.")
  parser.add_argument("--output-dir", default="/data/partner_tss3_captures", help="Output parent directory.")
  parser.add_argument("--label", default="", help="Human label, e.g. ignition_on_stationary or acc_active.")
  parser.add_argument("--owner", choices=["user", "partner", "unknown"], default="", help="Explicit owner classification.")
  parser.add_argument("--vehicle-tag", default="", help="Explicit vehicle tag, e.g. user_tss25 or partner_tss3.")
  parser.add_argument("--buses", default="all", help="'all' or comma-separated bus numbers.")
  parser.add_argument("--target-addrs", type=parse_addr_list, default=DEFAULT_TARGET_ADDRS, help="Comma-separated target CAN IDs.")
  parser.add_argument("--sync-addrs", type=parse_addr_list, default=DEFAULT_SYNC_ADDRS, help="Comma-separated sync CAN IDs.")
  parser.add_argument("--top-n", type=int, default=80, help="Number of top CAN IDs to include in summary.")
  parser.add_argument("--unique-cap", type=int, default=20000, help="Max unique payloads tracked per addr for summary counts.")
  args = parser.parse_args()
  capture(args)


if __name__ == "__main__":
  main()
